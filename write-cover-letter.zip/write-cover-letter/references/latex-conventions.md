# LaTeX conventions for this cover letter

The letter uses `moderncv` with `banking` style and blue accent. Output must be a complete file that compiles standalone in Overleaf — full preamble through `\end{document}`.

## Preamble (copy verbatim)

```latex
\documentclass[11pt,a4paper,roman]{moderncv}

\moderncvstyle{banking}
\moderncvcolor{blue}
\nopagenumbers{}

\usepackage[utf8]{inputenc}
\usepackage[scale=0.88]{geometry}
\usepackage{xcolor}
\usepackage{microtype}
\usepackage{fontawesome5}

\newcommand{\ksaheading}[1]{%
\par\vspace{6pt}%
\noindent{\bfseries\color{color1}#1}%
\par\vspace{2pt}%
\noindent{\color{color1}\rule{\linewidth}{0.6pt}}%
\par\vspace{6pt}%
}

\name{Ismail}{Hossain}
\title{PhD Candidate in Computer Science}
\phone[mobile]{+1~915-503-9122}
\email{ihossain@miners.utep.edu}
\homepage{ismail102.github.io/portfolio}
```

`color1` is defined by moderncv from `\moderncvcolor{blue}` — don't define it yourself.

## Document skeleton

```latex
\begin{document}

\makecvtitle
\vspace*{-10mm}

\today

\bigskip
\noindent\textbf{[Team Name]}\\
[Company Name]

\bigskip
\noindent Dear Hiring Team,

\medskip

[Opening paragraph — plain prose, no \noindent needed after the greeting.]

\ksaheading{[Theme One Heading]}

[Body paragraph.]

\ksaheading{[Theme Two Heading]}

[Body paragraph.]

\ksaheading{[Theme Three Heading]}

[Body paragraph.]

\ksaheading{Why [Company]}

[Why-company paragraph.]

\bigskip

[Closing paragraph.]

\bigskip
\noindent Sincerely,

\bigskip\bigskip\bigskip

\noindent\textbf{Ismail Hossain}\\
PhD Candidate in Computer Science\\
University of Texas at El Paso\\
\href{mailto:ihossain@miners.utep.edu}{ihossain@miners.utep.edu}
$\cdot$
+1 (915)-503-9122\\
\href{https://ismail102.github.io/portfolio}{ismail102.github.io/portfolio}

\end{document}
```

Note the recipient block: the bundled template has `\textbf{Memory \& Personalization Team}\` with a single backslash — that's a latent bug (it eats the following space). Use `\\` for the line break as shown above.

## Headings for `\ksaheading`

Short noun phrases in title case, mirroring the JD's theme vocabulary, e.g.:

- `\ksaheading{LLM Agent Systems and Evaluation}`
- `\ksaheading{Efficient Fine-Tuning and Alignment}`
- `\ksaheading{Research and Engineering Experience}`
- `\ksaheading{Why Workato}`

Keep them under ~6 words so the rule underneath reads as a section, not a sentence.

## Emphasis inside body text

Project names in italics: `\textit{SkillVetBench}`, `\textit{OPTIMUS}`. Use bold sparingly or not at all in body prose — the headings carry the visual structure.

## Character escaping

| Character | Write as |
|---|---|
| `&` | `\&` |
| `%` | `\%` |
| `$` | `\$` |
| `_` | `\_` |
| `#` | `\#` |

So: `R\&D`, `4G/5G`, `114{,}000` or `114,000` (both fine in prose).

## Page fit

One page is a hard constraint. The template fits one page with: opening, four `\ksaheading` body sections, a why-company section, and a closing. Three body sections is the safer default. If tight:

- Cut a body section before shrinking text
- The commented `% \newpage` in the template is a leftover — never uncomment it
- Do not reduce `scale=0.88` or the 11pt font; whitespace is part of the letter's readability

## File naming

`Cover_letter_Ismail_Hossain_<Company>.tex`, e.g. `Cover_letter_Ismail_Hossain_Workato.tex`. One file per application.
