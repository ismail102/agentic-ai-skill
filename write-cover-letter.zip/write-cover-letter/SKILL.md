---
name: write-cover-letter
description: Write a tailored, one-page LaTeX cover letter for Ismail Hossain from a job description, using his bundled resume (assets/Resume_Ismail_Hossain.tex) as the fact source and his bundled cover letter (assets/Cover_letter_Ismail_Hossain.tex) as the structure/voice template. The user only supplies a job description (pasted text or a URL). Use this skill whenever the user asks for a cover letter in any phrasing — "write a cover letter for this job", "cover letter for this JD", "draft my application letter", "write a letter of interest", "motivation letter for this position", or when they invoke /write-cover-letter. Also use it when the user has just tailored a resume for a JD in this conversation and now wants the accompanying letter. Output is ALWAYS a complete, compilable moderncv LaTeX file delivered as a .tex file. Do NOT use this skill for resume tailoring (use write-resume), for other people's cover letters, or for generic cover-letter advice.
---

# Write Cover Letter

Write a job-specific cover letter that an interviewer could probe line by line without the user ever having to walk anything back.

Cover letters tempt fabrication even more than resumes do, because the format rewards narrative: the model reaches for a story that fits the JD and invents connective tissue — motivations never felt, scope never had, numbers never measured. A cover letter is a set of claims the user must defend in an interview, in their own voice, from memory. So the same discipline as resume tailoring applies, plus one more rule specific to letters: **template facts are not facts**.

## Inputs and sources

Bundled with this skill:

- `assets/Resume_Ismail_Hossain.tex` — **the fact source.** Every factual claim in the letter must trace here, to a newer resume/CV the user supplied, or to something the user stated in this conversation.
- `assets/Cover_letter_Ismail_Hossain.tex` — **the structure and voice template.** Reuse its LaTeX skeleton, its section rhythm, and its register. Do NOT treat its content as a fact source: a template written for one job can contain claims that are stale, unverified, or wrong for the current application.

The only input the user provides is:

- **The job description** — pasted text or a URL to fetch. If it's missing, ask for it; don't guess a JD from a title.

If the conversation already contains a tailored resume for this same JD (e.g., from the write-resume skill), treat that tailoring as context: the letter should tell the story behind the same emphasis, using the same terminology choices.

**Freshness check (every run, one question).** The bundled resume is a snapshot. Before writing, confirm currency by anchoring on its most recent entries (the ACM CCS'26 and NeurIPS'26 "Under Review" papers) and asking whether there's a newer `.tex`. If the user already confirmed the resume earlier in this same conversation, don't re-ask — note that you're using the confirmed base and proceed.

## Known template landmines

Two claims in the bundled cover letter conflict with or exceed the resume. Do not reuse them without explicit confirmation from the user, and flag them if they come up:

- The template says **"Senior Software Engineer"** at Samsung R\&D; the resume says **"Software Engineer."** Job titles get verified by employers. Use the resume's title unless the user corrects the resume.
- The template cites **"261,000 execution traces"** for SkillVetBench. That number appears nowhere in the resume. Omit it unless the user confirms it — and if they do confirm it, suggest they add it to the resume too, since a letter and resume that disagree on numbers read as careless.

These two are examples of a general rule: whenever the template and the resume disagree, the resume wins, and the discrepancy gets surfaced to the user in the Gaps section.

## The grounding rule

Every claim — factual, quantitative, or biographical — must trace to the bundled resume, a newer resume/CV supplied this run, or a source the user provided in this conversation.

Permitted:
- Narrating work the resume states tersely ("built a 114K benchmark" → a sentence about why and how, staying within what the resume supports)
- Using the JD's terminology when it accurately describes the same work
- Expressing genuine-sounding motivation grounded in the user's actual research trajectory (his safety/agents/LLM arc is real; enthusiasm for it is fair game)
- Connecting his Samsung industry experience to industry roles

Forbidden:
- Inventing motivations tied to the company's specific product if nothing supports them ("I have long admired X's recommendation stack")
- Adding tools, methods, datasets, metrics, collaborations, or scope not in the sources
- Upgrading titles, inflating numbers, or importing template facts (see landmines above)
- Claiming experience from adjacency (evaluating agents ≠ building RL pipelines)

The interview test: *if the hiring manager circles a sentence and says "tell me more," can the user answer from work they actually did?* If not, cut it or move it to Gaps.

## Letter structure

Follow the template's skeleton exactly (see `references/latex-conventions.md` for the LaTeX). The content plan:

1. **Recipient block** — team name and company from the JD. If the JD names no team, use the department or "Hiring Team, [Company]".
2. **Opening paragraph** (4–6 sentences) — name the exact role and term (e.g., "Winter 2026 Research Intern"), current position, and a one-line research identity *reworded to lead with what this JD cares about*. If there's a genuine biographical hook (e.g., prior Samsung employment for a Samsung role), use it here — this is the strongest real personalization available. Include availability dates if the posting requires them.
3. **Three `\ksaheading` body sections** — each maps to one of the JD's top themes, ranked by the JD's own emphasis. Each section is anchored by ONE named project or experience with 1–2 concrete, resume-traceable details, then one sentence connecting it to the JD's language. Pick from the actual inventory: OPTIMUS/114K benchmark, SkillVetBench, AI-in-the-Loop, Multi-Agent Chat, SocialRec, Samsung engineering, teaching/mentorship, publications. Three sections is the default; four only if the JD genuinely has four distinct pillars AND the letter still fits one page.
4. **"Why [Company]"** section — must reference the JD's or team's actual stated mission/scope, not generic praise. If the JD describes the team's work in a distinctive way, echo that framing. Never invent familiarity with the company's products.
5. **Closing paragraph** — brief thanks, one sentence restating the fit in the JD's vocabulary. No new claims here.
6. **Signature block** — as in the template, with the resume's current title.

**Length is a hard constraint: one page.** The template compiles to one page with an opening, four sections, a why-company section, and a closing. If content runs long, cut a body section before shrinking anything else. Never let it spill to two pages — recruiters read letters in under a minute.

## Style rules

- Specific beats superlative. "Built a 114K-prompt benchmark for jailbreak resistance" outworks "extensive experience in cutting-edge AI safety." Every body paragraph needs at least one concrete noun an interviewer could ask about.
- One idea per sentence, mostly active voice, no throat-clearing ("I believe that", "I am confident that", "It is worth noting").
- Don't keyword-stuff. The JD's vocabulary should appear where it truthfully labels the work, roughly once per term.
- Vary sentence openings; don't start three consecutive sentences with "I".
- Mirror the template's register: professional, direct, warm in the closing — not effusive.
- No em-dash chains, no rule-of-three flourishes, no "passionate about leveraging synergies" filler. If a sentence could appear in anyone's cover letter, it's not doing work.

## Output format

Produce exactly this structure:

### 1. JD analysis (brief)
Three to five bullets: the role's top themes ranked, which resume assets map to each, and which theme each `\ksaheading` section will carry.

### 2. The letter
A complete, compilable `.tex` file — full preamble through `\end{document}` — written to the outputs directory and presented to the user (in claude.ai, save to `/mnt/user-data/outputs/` and share via the file-presentation tool; name it `Cover_letter_Ismail_Hossain_<Company>.tex`). Also show the body text inline briefly if the user wants to review without compiling. Follow `references/latex-conventions.md` for the preamble, `\ksaheading`, escaping, and the recipient/signature blocks.

### 3. Mapping rationale
One line per body section: the JD phrase it targets and the resume source it draws from. Lets the user audit in thirty seconds.

### 4. Gaps and flags
- JD themes the letter couldn't honestly cover, with a question about unlisted experience
- Any template/resume discrepancies encountered (including the landmines above if relevant)
- Logistics the letter needs from the user: availability dates, cohort choice, recipient name if known
- A reminder to compile once and check the one-page fit

## Working method

1. Read the JD closely; rank its themes; note its exact vocabulary.
2. Read the bundled resume (and any newer materials in the conversation). This inventory is the reference set for the grounding rule.
3. Choose the three body themes and their anchor projects. If the same JD was used for resume tailoring earlier in the conversation, keep terminology consistent with that tailoring.
4. Draft the letter following the structure above.
5. **Trace check — not optional.** Reread every sentence and locate its source in the resume or the user's statements. Anything untraceable gets cut or moved to Gaps. Check the two landmines specifically.
6. Compile-check mentally against `references/latex-conventions.md` (escapes, the `\ksaheading` command, moderncv fields), write the file, present it, then deliver sections 1, 3, and 4.
