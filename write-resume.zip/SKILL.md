---
name: write-resume
description: Tailor Ismail Hossain's LaTeX resume (bundled at assets/Resume_Ismail_Hossain.tex) to a specific job description, producing paste-ready LaTeX for the RESEARCH INTERESTS, TECHNICAL SKILLS, Graduate Research Associate, and SELECTED RESEARCH PROJECTS sections. The user only supplies a job description; the resume is already included. Use this skill whenever the user provides a job description or job posting and wants resume help — including phrasings like "tailor my resume for this role", "update my resume for this JD", "optimize my resume for ATS", "which keywords am I missing", "align my CV with this posting", or when they invoke /write-resume. Also use it when the user pastes a job ad without an explicit instruction, since the intent is almost always tailoring. Do NOT use this skill for building a resume from scratch or for non-Ismail resumes.
---

# Write Resume

Tailor an existing LaTeX resume to a job description without inventing credentials.

The single most important property of this skill is **truthfulness**. A resume is a claim the user has to defend in an interview. A fabricated bullet is worse than a missing keyword: it wastes an interview slot, damages the user's reputation, and the user cannot spot the fabrication because they trust the output. Optimizing for keyword density without a grounding constraint reliably produces fabrication — the model reaches for the JD's vocabulary and writes in experience that isn't there. Everything below exists to prevent that.

## Inputs

The resume is bundled with this skill at `assets/Resume_Ismail_Hossain.tex`. Read it as the base every run — the user does not need to supply it. The only input the user provides is:

- **The job description** — pasted text or a URL to fetch. If it's missing, ask for it. Don't guess at a JD from a job title alone.

**Freshness check (do this before tailoring, every run).** The bundled resume is a snapshot and can go stale as the user edits their real copy in Overleaf. Since a tailored resume gets sent to employers, silently working from an outdated version is a real cost. So before writing any output, confirm currency with one quick question. The most recent entries in the bundled copy are the ACM CCS 2026 and NeurIPS 2026 "Under Review" papers at the top of SELECTED PUBLICATIONS — surface that anchor and ask, e.g.:

> "I'm working from your bundled resume — most recent entries are the ACM CCS'26 and NeurIPS'26 submissions. Is this still current, or do you have a newer `.tex`?"

If the user provides a newer `.tex` (now or in the message), prefer theirs and use it as the base instead. If they confirm it's current, or a newer version isn't available, proceed with the bundled copy.

After the user edits their resume meaningfully, they should replace `assets/Resume_Ismail_Hossain.tex` in this skill folder so the snapshot stays current.

## The grounding rule

**Every claim in the output must trace to something already in the bundled resume (`assets/Resume_Ismail_Hossain.tex`), a newer `.tex` the user supplied this run, the user's CV, or a source they provided in this conversation.**

Permitted operations:
- Reorder bullets so the highest-signal content leads
- Reword using the JD's terminology *when it accurately describes the same work*
- Surface content buried in one section into a more visible one
- Merge, split, or compress existing bullets
- Add a metric that appears elsewhere in the user's materials

Forbidden:
- Adding a tool, framework, method, dataset, or metric that appears nowhere in the user's materials
- Inflating a number
- Describing work at a scale or scope the source doesn't support
- Implying a capability from adjacency ("they used DPO, so write RLHF")

When the JD asks for something the resume doesn't support, **do not write it in**. Record it in a Gaps list instead (see Output format). The gaps list is not a failure mode — it's the most useful part of the output, because it tells the user what to add themselves from experience that never made it onto the page.

### Terminology mapping is allowed; capability invention is not

The distinction matters and is easy to get wrong.

**Legitimate** — the underlying work is identical, only the label differs:
- Resume says "adversarial ML"; JD says "red-teaming" → use "red-teaming" (the user already lists both, and the jailbreak work is red-teaming)
- Resume says "jailbreak evaluation"; JD says "safety evaluation" → either is accurate
- Resume says "multi-agent LLM systems"; JD says "agentic systems" → same thing

**Illegitimate** — the label implies work that wasn't done:
- Resume says "DPO"; JD says "RLHF with human annotators" → different pipeline, do not claim it
- Resume says "differential privacy"; JD says "DP-SGD" → DP-SGD is a specific optimizer; only claim it if the source says so
- Resume says "federated learning"; JD says "secure aggregation" → related but distinct; check the source

Ask: *if an interviewer said "walk me through this," could the user answer from the work they actually did?* If no, it's a gap, not a rewrite.

## Sections to modify

By default, tailor these four:

1. **RESEARCH INTERESTS** — reorder and reword the 4-5 terms to lead with whatever the JD emphasizes most
2. **TECHNICAL SKILLS** — reorder rows and items within rows; surface JD keywords that are already true
3. **Graduate Research Associate** (in RESEARCH & INDUSTRY EXPERIENCE) — reorder and reword bullets; lead with the most JD-relevant
4. **SELECTED RESEARCH PROJECTS** — reorder projects; adjust the tag line after each project title

If the user names different sections, use theirs. If the JD is heavily industry-engineering-focused, consider also proposing changes to the Samsung entry, but flag it as optional.

## Output format

Produce exactly this structure:

### 1. JD analysis (brief)
Three to five bullets: what the role actually wants, ranked. Distinguish hard requirements from nice-to-haves. Note the JD's specific vocabulary — the exact phrases their ATS is likely keyed to.

### 2. Tailored LaTeX

For each section, a fenced `latex` block containing **only** the replacement text, using the resume's existing custom commands (`\customcventry`, `\textbullet`, `\href{...}{\faExternalLink}`, `\textcolor{blue}{...}`, etc.). The user pastes directly into Overleaf. Preserve:
- Escaped characters: `\&`, `\%`, `\$`, `\_`
- Math mode for symbols: `$\approx$`, `$\rightarrow$`, `$\leq$`, `$J(S,H)$`
- Em-dashes as `---`, en-dashes as `--`
- The `\\` line endings inside `itemize` blocks (this resume uses `\textbullet` + `\\`, not `\item`)

See `references/latex-conventions.md` for the full command inventory and formatting rules.

### 3. Change rationale
A compact table or list. One line per change: what changed, and the JD phrase it maps to. This lets the user audit the work in thirty seconds.

### 4. Gaps — not added
Everything the JD wants that the resume doesn't support. For each, state what's missing and ask whether the user has unlisted experience covering it. Be specific: "JD asks for RLHF with human preference data; your materials show DPO and GRPO only — do you have RLHF experience that isn't on the resume?"

## ATS reality check

Users often ask for a "90%+ ATS match." Be honest with them rather than pretending to optimize toward a score no one can measure.

What actually matters:
- **Parseability** — single column, standard section headers, no text in images or complex tables. This template is already fine.
- **Keyword presence** — the JD's exact terms appearing somewhere, in context. Presence, not density.
- **Title alignment** — if the JD says "Research Engineer" and the resume says "PhD Candidate," a line naming the target role helps.

What doesn't:
- Stuffing keywords into unrelated bullets
- Repeating a term to raise its frequency
- Any specific percentage claim about match rate

Say this plainly if the user asks for a numeric target. It's more useful than a false reassurance, and it redirects them toward the gaps list, which is the real path to a strong match.

## Working method

1. Read the JD closely. Identify hard requirements, preferred qualifications, and vocabulary.
2. Inventory what the user's materials actually contain. Do not skip this — it's the reference set for the grounding rule.
3. Map JD requirements onto that inventory. Sort into: *already there, surface it* / *there but poorly worded, relabel it* / *not there, gap*.
4. Write the LaTeX for the first two categories only.
5. Write the gaps list for the third.
6. Before delivering, reread each generated bullet and locate its source in the user's materials. Anything you can't trace, delete.

Step 6 is not optional. It catches the failure this skill exists to prevent.

## Notes on this particular resume

- The projects section describes a ChromaDB memory layer for Multi-Agent Chat. The public repo may still show FAISS. If the user hasn't pushed the migration, mention it once — anyone who opens the repo will notice the mismatch.
- The AI-in-the-Loop project's verifiable figures are: perplexity 22.3, engagement ≈0.80, relevance ≈0.74, PII leakage ≤0.0085, FedAvg up to 30 rounds, guard models LlamaGuard/LlamaGuard2/3/MD-Judge. Do not add other numbers to it.
- The user has substantial material not on the one-page resume (teaching, service, book chapters, older publications, additional awards). Pull from the full CV when the JD calls for it — that's surfacing, not inventing.
