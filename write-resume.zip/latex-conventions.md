# LaTeX conventions for this resume

The resume uses `moderncv` with `banking` style and a set of custom commands. Output must match these exactly or it won't compile when pasted into Overleaf.

## Contents
- [Document class and packages](#document-class-and-packages)
- [Custom commands](#custom-commands)
- [Section headers](#section-headers)
- [Bullet lists — the important quirk](#bullet-lists--the-important-quirk)
- [Character escaping](#character-escaping)
- [Math mode symbols](#math-mode-symbols)
- [Links and icons](#links-and-icons)
- [Section-by-section patterns](#section-by-section-patterns)

## Document class and packages

```latex
\documentclass[11pt,a4paper,roman]{moderncv}
\moderncvstyle{banking}
\usepackage[scale=0.9, top=0.50cm, bottom=0.50cm]{geometry}
```

Available: `fontawesome5`, `fontawesome`, `academicons`, `tabularx`, `enumitem`, `xcolor`, `hyperref`.

## Custom commands

`\customcventry` takes seven arguments (plus an optional leading spacing arg):

```latex
\customcventry{#2 dates}{#3 org/subtitle}{#4 bold title}{#5 bold right}{#6 unused}{#7 body}
```

In practice it's called as:

```latex
{\customcventry{Aug.\ 2022 - Present}{Security and Privacy Enhanced Machine Learning Lab}{\faFlask\ Graduate Research Associate}{El Paso, TX}{}
{
\begin{itemize}
  \textbullet First bullet.\\
  \textbullet Second bullet.
\end{itemize}
}}
```

Note the outer braces `{...}` wrapping the whole call. Keep them.

## Section headers

```latex
\section{\faSearch\ RESEARCH INTERESTS}
\section{\faCogs\ TECHNICAL SKILLS}
\section{\faBriefcase\ RESEARCH \& INDUSTRY EXPERIENCE}
\section{\faCode\ SELECTED RESEARCH PROJECTS}
\section{\faFlask\ SELECTED PUBLICATIONS}
\section{\faGraduationCap\ EDUCATION}
\section{\faTrophy\ AWARDS \& HONORS}
\section{\faNewspaper\ MEDIA COVERAGE}
\section{\faUsers\ TEACHING \& MENTORSHIP}
```

Vertical spacing is tuned by hand with `\vspace{-2ex}` / `\vspace{-4ex}` between sections. Don't remove these when replacing a section body — they live outside it.

## Bullet lists — the important quirk

This resume does **not** use `\item`. It uses `\textbullet` followed by `\\` at the end of each line, inside an `itemize` environment:

```latex
\begin{itemize}
  \textbullet Built a \textbf{114K} cybersecurity-grounded jailbreak dataset.\\
  \textbullet Designed and released \texttt{optimus-jbscorer} (PyPI).\\
  \textbullet Developed \textbf{SkillVetBench} for agentic skill ecosystems.
\end{itemize}
```

The final bullet has no trailing `\\`. Matching this matters — `\item` would render with different spacing and break the visual rhythm.

Some sections pass options: `\begin{itemize}[nosep, itemsep=6pt]`.

## Character escaping

| Character | Write as |
|---|---|
| `&` | `\&` |
| `%` | `\%` |
| `$` | `\$` |
| `_` | `\_` |
| `#` | `\#` |

So: `R\&D`, `89\% of malicious skills`, `\$2{,}000`, `write\_file`.

Inside `\href{...}` URLs, `%` must be `\%` too — e.g. `miners\%20pitch\%20competition`.

## Math mode symbols

| Symbol | Write as |
|---|---|
| ≈ | `$\approx$` |
| → | `$\rightarrow$` |
| ≤ | `$\leq$` |
| ≥ | `$\geq$` |
| J(S,H) | `$J(S,H)$` |
| VGM² | `VGM$^2$` |

Em-dash: `---`. En-dash (ranges): `--`, e.g. `24--39`, `0--10`. Note that some existing lines use a plain hyphen for ranges; either compiles, but `--` is typographically correct.

## Links and icons

External link icon after a title:

```latex
\textbf{SkillVetBench \href{https://github.com/supreme-lab/SkillVetBench/tree/master}{\faExternalLink}}
```

Inline link with visible text:

```latex
\href{https://pypi.org/project/optimus-jbscorer/}{\texttt{optimus-jbscorer}}
```

Icons in use: `\faSearch`, `\faCogs`, `\faBriefcase`, `\faCode`, `\faFlask`, `\faGraduationCap`, `\faTrophy`, `\faNewspaper`, `\faUsers`, `\faLaptopCode`, `\faExternalLink`, `\faGlobe`, `\faEnvelope`, `\faMobileAlt`, `\aiGoogleScholar`.

## Section-by-section patterns

### RESEARCH INTERESTS
Plain text, bold terms separated by `$\cdot$`:

```latex
\textbf{Agentic AI Security} $\cdot$ \textbf{LLM Safety \& Robustness} $\cdot$
\textbf{Adversarial ML \& Red-Teaming} $\cdot$
\textbf{Privacy-Preserving ML}
```

Four to five terms. More than five dilutes the signal.

### TECHNICAL SKILLS
A `tabular` with a bold right-aligned label column:

```latex
\begin{tabular}{>{\bfseries}r p{0.74\textwidth}}
Languages      & Python (primary), C, C++, Java, TypeScript \\
ML Frameworks  & PyTorch (primary), FSDP, DDP, Scikit-learn, HuggingFace Transformers \\
\end{tabular}
```

Every row ends `\\`, including the last. Row labels currently: Languages, ML Frameworks, LLM \& Agents, AI/ML Areas, Infrastructure, Databases, Open Source, Competitive CP.

Reordering rows and reordering items *within* a row are both good tailoring moves — the first item in each row carries the most weight.

### SELECTED RESEARCH PROJECTS
Each project: bold title with link icon, right-aligned tag line, then description on the next line.

```latex
\textbullet \textbf{SkillVetBench \href{URL}{\faExternalLink}} \hfill {\small\textit{Agentic AI Security $|$ LLM Evaluation $|$ Benchmarking $|$ HuggingFace}}\\
Description sentence, semicolon-separated clauses, ending with a period.\\
```

The `$|$` separators must be in math mode. Tags are the easiest high-value tailoring surface — they're scannable and map cleanly onto JD vocabulary.

### SELECTED PUBLICATIONS
Author list with the user bolded, italic title, link icon, bracketed venue, then a gray summary:

```latex
\textbullet \textbf{Hossain, Ismail}, Coauthor Name, and Sajedul Talukder.
\textit{``Title Here''}
\href{URL}{\faExternalLink}  -
[VENUE 2026 - Under Review]\\[2pt]
{\small\color{gray}
Summary sentence.}\\
```

Quotes are LaTeX-style: `` `` `` to open, `''` to close.
