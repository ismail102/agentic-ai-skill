---
name: cv-to-resume
description: >
  Use this skill whenever the user wants to create, tailor, generate, or rewrite a one-page resume
  from a CV or longer document, especially when a job description is provided. Trigger this skill
  when the user says things like: "write me a resume for this job", "tailor my CV for this position",
  "create a one-page resume from my CV", "customize my resume for this job description", "help me
  apply for this job with my CV", "make my resume match this JD", or uploads a CV/resume and asks
  for help applying. Also trigger when the user provides a job posting and wants their experience
  matched to it. Always use this skill when both a CV/resume and a job description are present in
  the conversation — this is the primary signal. Output is ALWAYS a complete, compilable LaTeX
  file in the exact format of Resume_Ismail_Hossain.tex (paracol, teal accent, custom commands).
---

# CV-to-Resume Skill

This skill generates a **targeted, one-page resume** from a full CV and a job description.
The output is a **complete, compilable LaTeX file** that exactly replicates the visual style,
structure, packages, and custom commands of `Resume_Ismail_Hossain.tex`.

---

## Bundled Reference Files

This skill ships with two reference files. **Read both before generating any output.**

| File | Purpose |
|---|---|
| `CV_Ismail_Hossain.tex` | The canonical source of all content — experience, publications, awards, skills |
| `Resume_Ismail_Hossain.tex` | The canonical output format — copy its preamble, commands, and layout exactly |

**How to use them:**
- Extract all factual content (dates, titles, bullet text, publication details, URLs, award names) from `CV_Ismail_Hossain.tex`
- Reproduce the document class, packages, color definitions, custom commands, section formatting, and two-column layout from `Resume_Ismail_Hossain.tex` verbatim
- Select and rewrite content for the target JD; never change the structure or styling

---

## Step-by-Step Process

### Step 1 — Read Both Reference Files

Before doing anything else, read:
1. `CV_Ismail_Hossain.tex` — extract all raw content
2. `Resume_Ismail_Hossain.tex` — internalize the preamble, custom commands, and layout

Do not proceed until both files are loaded into context.

---

### Step 2 — Parse the Job Description

From the JD extract:

- **Domain keywords** — must appear verbatim in the resume (e.g., if JD says "RAG", write "RAG")
- **Hard requirements** — degree level, languages, frameworks; all must appear in Technical Skills
- **Soft requirements** — open source, publications, leadership; include where CV supports them
- **Tone** — research-heavy means emphasize publications/benchmarks; industry means emphasize scale/metrics
- **Role tagline** — derive a 5–8 word subtitle for the header that mirrors the JD's domain

---

### Step 3 — Audit the CV: What to Include

| Section | Default | Rule |
|---|---|---|
| Education | Always | All degrees from CV |
| Research Experience | Always | 4–6 bullets, JD-aligned |
| Industry Experience | Always | 2–3 bullets |
| Selected Publications | 2–4 only | Most relevant to JD first; include URL if present in CV |
| Technical Skills | Always | Reorder: JD-required categories and tools first |
| Key Research Areas | Always (use \tag{}) | 8–10 terms, JD-matched |
| Awards & Honors | Top 4–8 | Use \awardentry{}{}; keep all if they fit |
| Media Coverage | Include if fits | Use \mediaentry{}{}{} |
| Service & Mentorship | Compact | 3–5 itemize lines |
| References | Always | Preserve names and emails from CV |
| Teaching Experience | Omit | Unless JD is academic/teaching role |

**One-page rule:** If content overflows, cut in this order: media coverage, lower-tier awards, service lines, then publication entries.

---

### Step 4 — Rewrite Bullets for the Target Role

Formula:
```
[Strong action verb] + [what you built/did] + [tool/method] + [measurable outcome or scale]
```

Rules:
- Mirror JD terminology exactly
- Front-load the most impressive detail
- Every bullet should have a number, scale, or named artifact where the CV supports it
- Eliminate: "worked on", "helped with", "responsible for", "assisted in"
- Bold the project/system name on first mention in a bullet: `\textbf{ProjectName}`
- Tag the publication venue at the end of a bullet: `--- \textbf{VENUE 'YY}`

Verb bank — Research: Designed, Developed, Proposed, Benchmarked, Evaluated, Formulated
Verb bank — Engineering: Built, Deployed, Optimized, Integrated, Scaled, Implemented, Automated
Verb bank — Leadership: Mentored, Led, Directed, Coordinated

---

### Step 5 — Select and Format Publications

Pick 2–4 from the CV ordered by: (1) relevance to JD topic, (2) venue prestige, (3) first-author.

Use `\pubentry` exactly as in `Resume_Ismail_Hossain.tex`:
```latex
\pubentry{VENUE YEAR \textnormal{(XX\% AR)}}{\textit{``Full Title''} \href{URL}{\faExternalLink} --- one-line impact statement tailored to JD}
```

If the paper is under review, use `\textnormal{\textit{(Under Review)}}` instead of acceptance rate.
If no URL is in the CV for that paper, omit the `\href` link.

---

### Step 6 — Generate the LaTeX File

Produce the complete file by following this structure exactly. Every element below must be
reproduced faithfully — do not simplify, substitute, or omit any package or command.

#### Preamble (copy verbatim from Resume_Ismail_Hossain.tex)

```latex
\documentclass[9pt, letterpaper]{article}

\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage[margin=0.4in, top=0.3in, bottom=0.3in]{geometry}
\usepackage{multicol}
\usepackage{enumitem}
\usepackage{titlesec}
\usepackage{xcolor}
\usepackage{hyperref}
\usepackage{array}
\usepackage{tabularx}
\usepackage{paracol}
\usepackage{fontawesome}

\definecolor{accent}{RGB}{15, 110, 86}
\definecolor{lightaccent}{RGB}{159, 225, 203}
\definecolor{muted}{RGB}{95, 94, 90}
\definecolor{dark}{RGB}{26, 26, 26}

\hypersetup{colorlinks=true, urlcolor=accent, linkcolor=accent}

\titleformat{\section}
  {\small\bfseries\color{accent}\scshape}
  {}{0em}{\MakeUppercase}
  [\color{lightaccent}\titlerule]
\titlespacing{\section}{0pt}{4pt}{2pt}

\setlist[itemize]{
  leftmargin=1em, itemsep=0pt, parsep=0pt, topsep=0.5pt,
  label=\textcolor{accent}{\textbullet}
}

\pagestyle{empty}

\newcommand{\entryheader}[3]{%
  {\small\textbf{#1}\hfill\textcolor{muted}{\footnotesize #2}}\\
  {\footnotesize\textit{\textcolor{muted}{#3}}}%
}
\newcommand{\pubentry}[2]{%
  \noindent{\footnotesize\textcolor{accent}{\textbf{#1}} - #2}\par\vspace{1pt}%
}
\newcommand{\skillrow}[2]{%
  \noindent{\footnotesize\textcolor{accent}{\textbf{#1}}\enspace #2}\par\vspace{1.5pt}%
}
\newcommand{\awardentry}[2]{%
  \noindent{\footnotesize\textbf{#1}}\\
  {\scriptsize\textcolor{muted}{#2}}\par\vspace{1.5pt}%
}
\newcommand{\mediaentry}[3]{%
  \noindent{\footnotesize\textbf{#1}}\\
  {\scriptsize\textcolor{accent}{#2}}\\
  {\scriptsize\textcolor{muted}{#3}}\par\vspace{1.5pt}%
}
\newcommand{\tag}[1]{%
  \colorbox{accent!10}{\textcolor{accent}{\scriptsize\textbf{#1}}}%
}
```

#### Header

```latex
\begin{center}
  {\LARGE\bfseries\color{accent} FULL NAME}\\[2pt]
  {\small\color{muted} DEGREE \& PROGRAM \quad\textbullet\quad JD-MATCHED TAGLINE}\\[3pt]
  {\footnotesize
    \href{mailto:EMAIL}{EMAIL} \quad
    PHONE \quad
    \href{https://WEBSITE}{WEBSITE} \quad
    \href{SCHOLAR_URL}{Google Scholar}
  }
\end{center}
\vspace{-2pt}
{\color{accent}\rule{\linewidth}{1.2pt}}
\vspace{1pt}
```

#### Two-Column Body

```latex
\setlength{\columnsep}{18pt}
\columnratio{0.62}
\begin{paracol}{2}

%% ── LEFT COLUMN ──────────────────────────────────────────
\section{Education}
\entryheader{DEGREE 1}{DATE}{Institution · Advisor (if research role)}\\
\entryheader{DEGREE 2}{DATE}{Institution}\\
\entryheader{DEGREE 3}{DATE}{Institution}

\section{Research \& Industry Experience}
\entryheader{JOB TITLE 1}{DATE RANGE}{Lab/Team, Institution}
\begin{itemize}
  \item BULLET using \textbf{ProjectName} and --- \textbf{VENUE 'YY} as appropriate
  ...
\end{itemize}

\vspace{1pt}
\entryheader{JOB TITLE 2}{DATE RANGE}{Company}
\begin{itemize}
  \item BULLET
  ...
\end{itemize}

\section{Selected Publications (Relevant to Role)}
\pubentry{VENUE YEAR \textnormal{(XX\% AR)}}{\textit{``Title''} \href{URL}{\faExternalLink} --- impact statement}
... (2-4 entries)

\section{Technical Skills}
\skillrow{Languages:}{...}
\skillrow{ML / DL:}{...}
\skillrow{LLM \& Agents:}{...}
\skillrow{CATEGORY:}{...}
\skillrow{Infra:}{...}
\skillrow{Databases:}{...}
\skillrow{Open Source:}{...}
\skillrow{Competitive CP:}{...}

%% ── RIGHT COLUMN ─────────────────────────────────────────
\switchcolumn

\section{Key Research Areas}
\noindent\footnotesize
\tag{AREA 1}\;
\tag{AREA 2}\;\\
\tag{AREA 3}\;
... (8-10 tags, line-break after every 2-3)

\section{Awards \& Honors}
\awardentry{AWARD NAME \href{URL}{\faExternalLink}}{Org, Year}
... (4-8 entries)

\section{Media Coverage}          %% omit if space-constrained
\mediaentry{TITLE \href{URL}{\faExternalLink}}{Source \textbullet\ Date}{Coverage description}
...

\section{Service \& Mentorship}
\begin{itemize}
  \item ...
\end{itemize}

\section{References}
\textbf{NAME} (Role) $\cdot$ Institution $\cdot$ \href{mailto:EMAIL}{EMAIL}

\end{paracol}
```

---

### Step 7 — Final Quality Check

**Content:**
- [ ] All JD hard-requirement keywords appear at least once
- [ ] Header tagline matches JD domain
- [ ] Every `\entryheader` bullet is rewritten for this JD (not copied verbatim from CV)
- [ ] Every `\pubentry` has a one-line impact statement tailored to JD

**LaTeX validity:**
- [ ] Special characters escaped: `&` → `\&`, `$` → `\$`, `%` → `\%`, `#` → `\#`, `_` → `\_`
- [ ] All `\href` URLs are valid strings (no spaces; from CV source)
- [ ] `\faExternalLink` used only where URL exists in CV
- [ ] No placeholder text remaining (no "FULL NAME", "DATE", "BULLET", etc.)
- [ ] `\begin{paracol}` and `\end{paracol}` are balanced; `\switchcolumn` appears exactly once

**Style fidelity:**
- [ ] `\definecolor{accent}{RGB}{15, 110, 86}` — never changed
- [ ] Section titles use `\section{}` (not `\section*{}`) — paracol handles numbering off via `\pagestyle{empty}`
- [ ] `\entryheader` used for all experience and education entries (not raw `\textbf` + `\hfill`)
- [ ] `\pubentry`, `\skillrow`, `\awardentry`, `\mediaentry`, `\tag` used in their respective sections
- [ ] `\columnratio{0.62}` — never changed

**Honesty:**
- [ ] All content grounded in CV — no invented metrics, titles, or papers
- [ ] Numbers not inflated beyond what CV states

---

## Output Delivery

1. Output the **complete LaTeX file** — compilable with `pdflatex`, no truncation, no remaining placeholders
2. Follow immediately with a **Tailoring Notes** block (outside the code fence):
   - What was prioritized and why (mapped to JD)
   - What was cut and why
   - Gaps between the JD and CV to prepare for in interviews

---

## Hard Rules — Never Violated

- **Never output Markdown** as the resume — LaTeX only
- **Never change the accent color** (`RGB{15, 110, 86}`)
- **Never replace `paracol` with `minipage`** — the column model must stay `paracol`
- **Never replace custom commands** with raw LaTeX equivalents — `\entryheader`, `\pubentry`, `\skillrow`, `\awardentry`, `\mediaentry`, `\tag` must all appear in the output
- **Never invent content** — every claim must trace to a line in `CV_Ismail_Hossain.tex`
- **Never leave placeholders** — the delivered file must be ready to compile as-is
