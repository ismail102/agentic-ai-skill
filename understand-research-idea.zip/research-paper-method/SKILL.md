---
name: research-paper-method
description: >
  Use this skill whenever the user wants to review, critique, write, or brainstorm a research paper,
  academic paper, or technical paper using a structured problem-prior work-limitation-proposal framework.
  Trigger this skill when the user mentions: reviewing a paper, writing a paper introduction, evaluating
  research contributions, identifying limitations of prior work, framing a new idea as a research contribution,
  structuring an abstract or introduction, or comparing their method to baselines. Also trigger when the user
  presents a raw idea and wants to frame it as a research paper, or asks "how does my work differ from X, Y, Z".
  This skill applies to ANY research domain: ML, systems, biology, medicine, social science, economics, etc.
---

# Research Paper Method Skill

This skill applies a structured 8-step framework for both **reviewing existing papers** and **writing/framing new research ideas**. The framework is grounded in how strong paper introductions are constructed in top-tier venues.

---

## The Core Framework

```
We consider [PROBLEM].

This problem is important because [IMPORTANCE/MOTIVATION].

Historically, existing work (a) [METHOD_A], (b) [METHOD_B], (c) [METHOD_C]
have been used to attack this problem.

However, there are fundamental difficulties:
  - Limitation of (a): [LIMITATION_A]
  - Limitation of (b): [LIMITATION_B]
  - Limitation of (c): [LIMITATION_C]

Because of these limitations, [NEGATIVE CONSEQUENCE — what goes wrong in practice].

We propose [PROPOSED METHOD / IDEA].

The fundamental difference from (a), (b), (c) is [KEY NOVELTY].

Because of this difference, our method can solve [SPECIFIC CLAIM / CONTRIBUTION].
```

---

## Two Modes of Use

### Mode 1 — Reviewing an Existing Paper

When the user provides a paper (text, PDF, or summary), walk through the 8 steps below and evaluate how well the paper addresses each one. Flag gaps, weak justifications, or missing comparisons.

### Mode 2 — Writing / Framing a New Idea

When the user has a new idea, hypothesis, or prototype, help them populate the framework above to turn their idea into a well-structured research narrative.

---

## The 8-Step Process

### Step 1 — Define the Problem

**Question to answer:** What is the core problem being studied?

- State it precisely. Avoid vague language like "we study AI" — prefer "we study the problem of X under constraint Y."
- The problem should be a gap, a failure mode, or an unmet need — not just a topic.

**When reviewing:** Check if the problem is crisply defined in the abstract/intro. If it's buried or ambiguous, flag it.

**When writing:** Help the user articulate the problem as a single declarative sentence. Push back if it's too broad.

---

### Step 2 — Establish Importance

**Question to answer:** Why does this problem matter? Who is affected if it isn't solved?

- Ground importance in real-world consequences, scale, cost, safety, or scientific significance.
- Avoid circular justification (e.g., "it's important because it's hard").

**When reviewing:** Does the paper motivate the problem with evidence or compelling reasoning, or does it assert importance without justification?

**When writing:** Help the user find 2–3 concrete reasons this problem matters. Use data, failure cases, or downstream impact if possible.

---

### Step 3 — Survey Prior Work (a), (b), (c)

**Question to answer:** What are the main families or classes of existing approaches?

- Organize prior work into 2–4 meaningful categories (not a flat list of citations).
- Each category should represent a distinct *strategy* for tackling the problem.

**When reviewing:** Is prior work organized by approach type? Are any major categories missing? Are citations cherry-picked?

**When writing:** Help the user identify the main camps in the literature. If they don't know the literature well, flag this as a research gap to fill before submission.

---

### Step 4 — Identify Fundamental Limitations

**Question to answer:** Why do each of (a), (b), (c) fail to fully solve the problem?

- Limitations must be *fundamental* (structural, not just implementation bugs) to justify new work.
- Pair each prior work category with a specific, named limitation.

**When reviewing:** Are limitations clearly articulated and paired to specific prior work? Or are they vague ("prior methods are slow")? Are limitations verified with experiments or citations?

**When writing:** For each prior work category the user identified, surface the core assumption or design choice that creates the limitation. Strong papers often include a short theorem or experiment demonstrating the limitation.

---

### Step 5 — State the Negative Consequence

**Question to answer:** What goes wrong *in practice* because of these limitations?

- This connects the theoretical gap to real-world harm or suboptimal outcomes.
- Examples: models fail on out-of-distribution data, algorithms are intractable at scale, methods require unavailable supervision.

**When reviewing:** Does the paper make this connection explicit, or does it jump straight from limitations to the proposal? Missing this step weakens the motivation.

**When writing:** Help the user articulate what a practitioner actually experiences when using current methods. This is the "pain point" that makes the reader care about the solution.

---

### Step 6 — Present the Proposed Method

**Question to answer:** What is the proposed solution?

- Name the method clearly.
- Describe it at a conceptual level: what does it do differently?
- Defer technical detail to later sections; the intro should give intuition.

**When reviewing:** Is the proposal described clearly enough in the intro to be understood without reading the rest of the paper? Is it presented as a logical response to the limitations identified?

**When writing:** Help the user articulate their method in 2–4 sentences at a high level. Ensure it logically responds to at least one of the limitations in Step 4.

---

### Step 7 — Articulate the Key Novelty

**Question to answer:** What is the *fundamental difference* between this proposal and (a), (b), (c)?

- Novelty should be a specific design choice, insight, or mechanism — not just "we combine X and Y."
- The difference should map directly to overcoming the limitations in Step 4.

**When reviewing:** Is novelty clearly stated? Is it non-trivial? Does it actually address the stated limitations, or is it disconnected?

**When writing:** Ask the user: "What is the one thing your method does that none of (a), (b), (c) can do?" That's your novelty claim. Be specific.

---

### Step 8 — State What the Method Solves (Contribution Claim)

**Question to answer:** What can this method now do that prior work could not?

- This is the payoff. It should be falsifiable and tied to experiments.
- Strong claims: "achieves X% improvement on benchmark Y", "provably converges when Z", "runs in O(n log n) instead of O(n²)".

**When reviewing:** Are contribution claims specific and backed by results? Or are they vague ("achieves better performance")?

**When writing:** Help the user turn their intuition into 2–3 concrete, measurable contribution bullets.

---

## Output Format

### For Paper Review

Produce a structured critique using this template:

```
## Paper Review: [Title]

### Step 1 — Problem Definition
[Assessment + quoted evidence from paper]

### Step 2 — Importance
[Assessment]

### Step 3 — Prior Work Coverage
[Assessment — any missing categories?]

### Step 4 — Limitations
[Assessment — are they fundamental and paired?]

### Step 5 — Negative Consequences
[Assessment — is the gap → harm link explicit?]

### Step 6 — Proposed Method
[Assessment — is it clear and motivated?]

### Step 7 — Novelty
[Assessment — is it specific and non-trivial?]

### Step 8 — Contribution Claims
[Assessment — specific and falsifiable?]

### Overall Verdict
[Strengths / Weaknesses / Recommendations]
```

### For Writing / Framing a New Idea

Produce a populated draft of the core framework, then annotate each part with confidence level and open questions:

```
## Research Paper Draft: [Working Title]

**Problem:** ...
**Importance:** ...
**Prior Work (a/b/c):** ...
**Limitations:** ...
**Negative Consequence:** ...
**Proposed Method:** ...
**Key Novelty:** ...
**Contribution Claims:** ...

---
### Open Questions Before Submission
- [ ] Is prior work coverage complete?
- [ ] Are limitations supported by evidence?
- [ ] Are contribution claims measurable?
```

---

## Tips for Strong Execution

- **Limitations must be fundamental.** If a limitation is "prior work didn't tune hyperparameters well," that's an implementation issue, not a fundamental barrier. Push for structural limitations.
- **Novelty must be specific.** "We propose a new framework" is not novelty. "We are the first to exploit property X to overcome limitation Y" is.
- **Causality matters.** The chain Problem → Limitation → Consequence → Proposal should feel like logical necessity, not a list of marketing bullets.
- **Don't skip Step 5.** Many weak papers jump from limitations to proposal without explaining why the limitations matter in practice. This is where reviewers disengage.
- **Contribution claims should match experiments.** Every claim in Step 8 should correspond to at least one experiment or proof in the paper.
